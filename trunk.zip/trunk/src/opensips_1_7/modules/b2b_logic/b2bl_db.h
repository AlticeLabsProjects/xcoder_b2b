/*
 * $Id: b2bl_db.h 8370 2011-09-13 22:28:00Z osas $
 *
 * back-to-back logic module
 *
 * Copyright (C) 2011 Free Software Fundation
 *
 * This file is part of opensips, a free SIP server.
 *
 * opensips is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version
 *
 * opensips is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software 
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * History:
 * --------
 *  2011-04-04  initial version (Anca Vamanu)
 */

#ifndef B2BL_DB_H
#define B2BL_DB_H

#include "records.h"

void b2b_logic_dump(int no_lock);
int b2b_logic_restore(void);
void b2bl_db_insert(b2bl_tuple_t* tuple);
void b2bl_db_update(b2bl_tuple_t* tuple);

#endif
